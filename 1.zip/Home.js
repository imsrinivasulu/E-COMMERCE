// fetch("https://fakestoreapi.com/products")
// .then((res)=>{
//     let finalOutput=res.json()
//     finalOutput.then((Output)=>{
//         Output.forEach((ele,index,arr)=>{
//             let main=document.getElementById("container")
//             main.innerHTML+=`
//             <h1>${ele.id}</h1>
//             <h1>${ele.price}</h1>
//             <img src=${ele.image}>
//             <p>${ele.description}</p>
//             `
//         })
//     })
// })

//!

let cartCount = 0;
let totalAmount = 0;

fetch("https://fakestoreapi.com/products")
    .then((res) => res.json())
    .then((output) => {
        output.forEach((product) => {
            const section = document.getElementById("container");
            const productContainer = document.createElement("div");
            productContainer.className = "product";

            productContainer.innerHTML = `<div>
                <img src=${product.image} alt="${product.title}">
                <h1>${product.title.slice(0,50)}</h1>
                <p>${product.description.slice(0,100)}</p>
                <h2>Rs: ${product.price}</h2>
                <main id="order_details">
                <button class="add-to-cart-btn" data-price="${product.price}">Add to Cart</button>
                <a href="./buynow.html"><button class="buy-now">Buy Now</button></a>
                </main>
                </div>
            `;

            section.appendChild(productContainer);
        });
// let finalOutput=document.getElementById()
        document.querySelectorAll(".add-to-cart-btn").forEach((button) => {
            button.addEventListener("click", (event) => {
                const price = parseFloat(event.target.dataset.price);
                cartCount++;
                totalAmount += price;
                document.getElementById("cart-count").textContent = cartCount;
                document.getElementById("total-amount").textContent = `Total Amount: Rs:${totalAmount.toFixed(2)}
                `;
                // <a href="./buynow.html"><button class="buy-now">Buy Now</button></a>
                
            });
        });
    })
    .catch((err) => console.error(err));

    document.addEventListener('DOMContentLoaded', function() {
        const username = localStorage.getItem('username');
        if (username) {
            document.getElementById('username').textContent = username;
        } else {
            window.location.href = './index.html';
        }
    });

