document.addEventListener('DOMContentLoaded', function() {
    const username = localStorage.getItem('username');
    if (username) {
        document.getElementById('username').textContent = username;
        // Assuming email and other details are stored similarly
        const email = localStorage.getItem('email');
        if (email) {
            document.getElementById('email').textContent = email;
        }
    } else {
        window.location.href = './index.html';
    }
});