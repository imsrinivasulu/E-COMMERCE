// fetch(data)

let cart_value=document.getElementById("cart_details")

let addToCart=(product)