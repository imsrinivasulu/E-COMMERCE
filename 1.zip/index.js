let form=document.querySelector("form")
form.addEventListener("submit",(event)=>{
    event.preventDefault()
    let username=document.getElementById("username").value
    let password=document.getElementById("password").value
    let login_id=localStorage.getItem("username")
    let login_passsword=localStorage.getItem("password")
    if(username==login_id && password==login_passsword){
        open("./Home.html","__self")
    }
    else{
        alert("please check the credentials🤮")
    }
})

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    localStorage.setItem('username', username);
    window.location.href = './Home.html';
});
