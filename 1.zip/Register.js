let form=document.querySelector("form")
form.addEventListener("submit",(event)=>{
    event.preventDefault()
    let username=document.getElementById("username").value
    let password=document.getElementById("password").value
    localStorage.setItem("username",username)
    localStorage.setItem("password",password)
    alert("SUCCESSFULLY REGISTERED🤩")
    open("./index.html","__self")
})

document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    localStorage.setItem('username', username);
    window.location.href = './index.html';
});